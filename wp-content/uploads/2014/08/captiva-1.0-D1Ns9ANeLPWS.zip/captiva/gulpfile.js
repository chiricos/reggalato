/*!
 * gulp
 * $ npm install gulp-ruby-sass gulp-autoprefixer gulp-minify-css gulp-jshint gulp-concat gulp-uglify gulp-imagemin gulp-clean gulp-notify gulp-rename gulp-livereload gulp-cache --save-dev
 */
 
// Load plugins
var gulp = require('gulp'),
    //sass = require('gulp-ruby-sass'),
    //autoprefixer = require('gulp-autoprefixer'),
    //minifycss = require('gulp-minify-css'),
    jshint = require('gulp-jshint'),
    uglify = require('gulp-uglify'),
    filesize = require('gulp-filesize'),
    minifyCSS = require('gulp-minify-css'),
    gulpIgnore = require('gulp-ignore');
    //imagemin = require('gulp-imagemin'),
    rename = require('gulp-rename'),
    clean = require('gulp-clean'),
    concat = require('gulp-concat'),
    notify = require('gulp-notify'),
    cache = require('gulp-cache'),
    livereload = require('gulp-livereload');

var paths = {
  corecss: ['css/*.css', '!css/ie.css'],
};
 
// // Styles
// gulp.task('styles', function() {
//   return gulp.src('src/styles/main.scss')
//     .pipe(sass({ style: 'expanded', }))
//     .pipe(autoprefixer('last 2 version', 'safari 5', 'ie 8', 'ie 9', 'opera 12.1', 'ios 6', 'android 4'))
//     .pipe(gulp.dest('dist/styles'))
//     .pipe(rename({ suffix: '.min' }))
//     .pipe(minifycss())
//     .pipe(gulp.dest('dist/styles'))
//     .pipe(notify({ message: 'Styles task complete' }));
// });
 
// Scripts
gulp.task('scripts', function() {
  return gulp.src('js/src/*.js')
//    .pipe(jshint('.jshintrc'))
    .pipe(jshint())
    .pipe(jshint.reporter('default'))
    .pipe(concat('captiva.js'))
    .pipe(gulp.dest('js/dist/build'))
    //.pipe(filesize())
    .pipe(rename({ suffix: '.min' }))
    .pipe(uglify())
    .pipe(gulp.dest('js/dist'))
    //.pipe(filesize())
    .pipe(notify({ message: 'Scripts task complete' }));
});

// Scripts 2
gulp.task('pluginscripts', function() {
  return gulp.src('js/src/plugins/*.js')
//    .pipe(jshint('.jshintrc'))
    .pipe(jshint())
    .pipe(jshint.reporter('default'))
    .pipe(concat('plugins.js'))
    .pipe(gulp.dest('js/dist/build'))
    //.pipe(filesize())
    .pipe(rename({ suffix: '.min' }))
    .pipe(uglify())
    .pipe(gulp.dest('js/dist'))
    //.pipe(filesize())
    .pipe(notify({ message: 'Plugin Scripts task complete' }));
});

// Styles
var condition = 'css/ie.css';

gulp.task('cssmin', function() {
  return gulp.src(paths.corecss)
  //return gulp.src('css/*.css')
    //.pipe(gulpIgnore.exclude(condition))
    .pipe(minifyCSS())
    //.pipe(gulpIgnore.exclude(condition))
    .pipe(concat('all.css'))
    .pipe(gulp.dest('css/min/'))
    .pipe(rename({ suffix: '.min' }))
    .pipe(gulp.dest('css/min/'))
    .pipe(notify({ message: 'CSS minification task complete' }));
});

 
// // Images
// gulp.task('images', function() {
//   return gulp.src('src/images/**/*')
//     .pipe(cache(imagemin({ optimizationLevel: 3, progressive: true, interlaced: true })))
//     .pipe(gulp.dest('dist/images'))
//     .pipe(notify({ message: 'Images task complete' }));
// });
 
// // Clean
// gulp.task('clean', function() {
//   return gulp.src(['dist/styles', 'dist/scripts', 'dist/images'], {read: false})
//     .pipe(clean());
// });
 
// Default task
// gulp.task('default', ['clean'], function() {
// gulp.task('default', ['scripts'], function() {
//     gulp.start('styles', 'scripts', 'images');
//     gulp.start('scripts');
// });

  gulp.task('default', ['scripts']);
 
// Watch
gulp.task('watch', function() {
 
  // Watch .scss files
  //gulp.watch('src/styles/**/*.scss', ['styles']);
 
  // Watch .js files
  gulp.watch('js/src/*.js', ['scripts']);
  gulp.watch('js/src/plugins/*.js', ['pluginscripts']);
  gulp.watch('css/*.css', ['cssmin']);
 
  // Watch image files
  //gulp.watch('src/images/**/*', ['images']);
 
  // Create LiveReload server
  //var server = livereload();
 
  // Watch any files in dist/, reload on change
  //gulp.watch(['dist/**']).on('change', function(file) {
  //  server.changed(file.path);
  });
 