<?php
/**
 * The header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="content">
 *
 * @package captiva
 */
global $captiva_options;
$cap_responsive_status = '';
$cap_preloader_status = '';
$cap_logo = '';
$cap_favicon = '';
$cap_favicon = $captiva_options['cap_favicon']['url'];
$cap_retina_favicon = $captiva_options['cap_retina_favicon']['url'];
$cap_topbar_display = '';
$cap_topbar_display = $captiva_options['cap_topbar_display'];
$cap_topbar_message = $captiva_options['cap_topbar_message'];
$cap_display_cart = '';
$cap_display_cart = $captiva_options['cap_show_cart'];
$cap_catalog = '';
$cap_catalog = $captiva_options['cap_catalog_mode'];
$cap_sticky_menu = '';
$cap_sticky_menu = $captiva_options['cap_sticky_menu'];

if (!empty($_SESSION['cap_header_top'])){
    $cap_topbar_display = $_SESSION['cap_header_top'];
}

?>
<!DOCTYPE html>
<!--[if IE 8]>    <html lang="en-us" class="no-js ie8"> <![endif]--> 
<!--[if IE 9]>    <html lang="en-us" class="no-js ie9"> <![endif]--> 
<!--[if gt IE 8]><!--> <html lang="en-us" class="no-js"> <!--<![endif]--> 
    <head>
        <meta charset="<?php bloginfo( 'charset' ); ?>">
        <?php
        $cap_responsive_status = $captiva_options['cap_responsive'];
        if ( $cap_responsive_status == 'enabled' ) {
            ?>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <?php } ?>
        <title><?php wp_title( '|', true, 'right' ); ?></title>
        <link rel="profile" href="http://gmpg.org/xfn/11">
        <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">        
        <link rel="shortcut icon" href="<?php
        if ( $cap_favicon ) { 
            echo $cap_favicon; 
        } else { ?><?php echo get_template_directory_uri(); ?>/favicon.png<?php }?>"/>

         <link rel="shortcut icon" href="<?php
        if ( $cap_retina_favicon ) { 
            echo $cap_retina_favicon; 
        } else { ?><?php echo get_template_directory_uri(); ?>/apple-touch-icon-precomposed.png<?php }?>"/>

       <?php wp_head(); ?>
       
       <script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.min.js"></script>
       <script src="http://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7/html5shiv.js"></script>

    </head>
    <body id="skrollr-body" <?php body_class(); ?>>
        <?php
        $cap_preloader_status = $captiva_options['cap_preloader'];
        if ( $cap_preloader_status == 'enabled' ) {
            ?>
            <div id="preloader">
                <div id="status">
                    <div class="loader-container">
                        <div class="ball"></div>
                        <div class="ball"></div>
                        <div class="ball"></div>
                        <div class="ball"></div>
                        <div class="ball"></div>
                        <div class="ball"></div>
                        <div class="ball"></div>
                    </div>
                </div>
            </div>
            <!-- /preloader -->
        <?php } ?>

        <div id="wrapper">
            <?php
            if ( $cap_topbar_display == 'yes' ) {
                ?>
                <div id="top">
                    <div class="container">
                        <div class="row">
                            <div class="top-msg-wrap col-lg-6 col-md-6 col-sm-6 hidden-xs">
                                <?php
                                if ( $cap_topbar_message ) {
                                    ?>
                                    <div class="top-bar-msg"><?php echo $cap_topbar_message; ?></div>
                                <?php } ?>
                            </div>
                            <div class="top-nav-wrap col-lg-6 col-md-6 col-sm-6 hidden-xs">
                                <!-- Single button -->
                                <div id="top-menu-wrap">
                                    <ul class="nav-pills top-menu pull-right">
                                        <?php
                                        wp_nav_menu( array(
                                            'menu' => 'top',
                                            'theme_location' => 'top',
                                            'depth' => 2,
                                            'container' => false,
                                            'container_class' => false,
                                            'items_wrap' => '%3$s',
                                            'fallback_cb' => 'wp_bootstrap_navwalker::fallback',
                                            'walker' => new wp_bootstrap_navwalker()
                                                )
                                        );
                                        ?>
                                    </ul>
                                </div>
                                <div id="top-bar-wrap">
                                    <?php if ( is_active_sidebar( 'top-bar-search' ) ) : ?>
                                        <div id="top-bar-search">
                                            <?php dynamic_sidebar( 'top-bar-search' ); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php } ?>

            <div class="standard-menu">
                <div class="container">
                    <div class="menu-wrapper">
                        <div class="main-nav">
                            <div class="row">
                                <div class="container">
                                    <div class="menu-wrapper">
                                        <?php if ( $cap_display_cart ) { ?>
                                            <?php if ( $cap_catalog == 'disabled' ) { ?>
                                                <div class="cart-wrap">
                                                    <?php if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
                                                        ?>
                                                        <?php echo captiva_woocommerce_cart_dropdown(); ?>
                                                    <?php }
                                                    ?>
                                                </div>
                                            <?php } ?>
                                        <?php } ?>

                                        <?php
                                        $cap_logo = $captiva_options['site_logo']['url'];

                                        if ( !empty ( $_SESSION['cap_skin_color'] ) ){
                                            $cap_skin_color = $_SESSION['cap_skin_color'];
                                            if ( $cap_skin_color == '#169fda' ) {
                                                $cap_logo = 'http://captivabeta.captivate.io/wp-content/uploads/2014/07/logo_blue.png';
                                            } elseif ( $cap_skin_color == '#dd3333' ) {
                                                $cap_logo = 'http://captivabeta.captivate.io/wp-content/uploads/2014/07/logo_red.png';
                                            } elseif ( $cap_skin_color == '#208e3c' ) {
                                                $cap_logo = 'http://captivabeta.captivate.io/wp-content/uploads/2014/07/logo_green.png';
                                            } elseif ( $cap_skin_color == '#dd9933' ) {
                                                $cap_logo = 'http://captivabeta.captivate.io/wp-content/uploads/2014/07/logo_orange.png';
                                            }
                                        }

                                        if ( $cap_logo ) {
                                            $cap_logo_width = $captiva_options['site_logo']['width'];
                                            $cap_logo_max_width = $cap_logo_width / 2;
                                            ?>

                                            <div class="logo image">
                                                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" style="max-width: <?php echo $cap_logo_max_width; ?>px;">
                                                    <span class="helper"></span><img src="<?php echo $cap_logo; ?>" alt="<?php bloginfo( 'name' ); ?>"/></a>
                                            </div>
                                        <?php } else { ?>
                                            <div class="logo text-logo">
                                                <h1><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
                                            </div>
                                        <?php } ?>
                                        <?php if ( has_nav_menu( 'primary' ) ) { ?>
                                            <?php
                                            wp_nav_menu( array(
                                                'theme_location' => 'primary',
                                                'before' => '',
                                                'after' => '',
                                                'link_before' => '',
                                                'link_after' => '',
                                                'depth' => 4,
                                                'fallback_cb' => false,
                                                'walker' => new Cg_Menu())
                                            );
                                            ?>
                                        <?php } else { ?>
                                            <p class="setup-message">You can set your main menu in <strong>Appearance &gt; Menus</strong></p>
                                        <?php } ?>

                                    </div><!--/menu-wrapper -->
                                </div><!--/container -->
                            </div><!--/row -->
                        </div><!--/main-nav -->
                    </div><!--/menu-wrapper -->
                </div><!--/container -->
            </div><!--/standard-menu -->
            <?php 
            if ( $cap_sticky_menu == 'yes' ) {
            ?>
            <!--FIXED -->
            <div class="fixed-header-area fixed-menu-type">
                <div class="fixed-header">
                    <div class="container">
                        <div class="menu-wrapper">
                            <div class="main-nav">
                                <div class="row">
                                    <div class="container">
                                        <div class="menu-wrapper">
                                            <?php if ( $cap_display_cart ) { ?>
                                                <?php if ( $cap_catalog == 'disabled' ) { ?>
                                                    <div class="cart-wrap">
                                                        <?php if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
                                                            ?>
                                                            <?php echo captiva_woocommerce_cart_dropdown(); ?>
                                                        <?php }
                                                        ?>
                                                    </div>
                                                <?php } ?>
                                            <?php } ?>

                                            <?php
                                            $cap_logo = $captiva_options['site_logo']['url'];
                                            if ( $cap_logo ) {
                                                $cap_logo_width = $captiva_options['site_logo']['width'];
                                                $cap_logo_max_width = $cap_logo_width / 2;
                                                ?>

                                                <div class="logo image">
                                                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" style="max-width: <?php echo $cap_logo_max_width; ?>px;">
                                                        <span class="helper"></span><img src="<?php echo $cap_logo; ?>" alt="<?php bloginfo( 'name' ); ?>"/></a>
                                                </div>
                                            <?php } else { ?>
                                                <div class="logo text-logo">
                                                    <h1><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
                                                </div>
                                            <?php } ?>
                                            <?php if ( has_nav_menu( 'primary' ) ) { ?>
                                                <?php
                                                wp_nav_menu( array(
                                                    'theme_location' => 'primary',
                                                    'before' => '',
                                                    'after' => '',
                                                    'link_before' => '',
                                                    'link_after' => '',
                                                    'depth' => 4,
                                                    'fallback_cb' => false,
                                                    'walker' => new Cg_Menu())
                                                );
                                                ?>
                                            <?php } else { ?>
                                                <p class="setup-message">You can set your main menu in <strong>Appearance &gt; Menus</strong></p>
                                            <?php } ?>

                                        </div><!--/menu-wrapper -->
                                    </div><!--/container -->
                                </div><!--/row -->
                            </div><!--/main-nav -->
                        </div><!--/menu-wrapper -->
                    </div><!--/container -->
                </div><!--/fixed-header -->
            </div><!--/fixed-header-area -->
            <?php }
            ?>
            <div id="load-mobile-menu">
            </div>

            <div id="mobile-menu">
                <a id="skip" href="#cap-page-wrap" class="hidden" title="<?php esc_attr_e( 'Skip to content', 'captiva' ); ?>"><?php _e( 'Skip to content', 'captiva' ); ?></a> 
                <?php
                if ( function_exists( 'has_nav_menu' ) && has_nav_menu( 'primary' ) ) {
                    wp_nav_menu( array('theme_location' => 'primary', 'container' => 'ul', 'menu_id' => 'mobile-main-nav', 'menu_class' => 'mobile-menu-wrap', 'walker' => new menu_walker()) );
                }
                ?>
            </div><!--/mobile-menu -->

            <div id="cap-page-wrap" class="hfeed site">
                <?php do_action( 'before' ); ?>