<?php
/**
 * Product Loop End
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.0.0
 */
?>
	<?php //if ( !empty( $woo_product_grid_count ) ) { ?>
	</ul>
	<?php //} ?>
    </div>
</div>